#python3
#a program by your senpai

class Card:
	#class card to be used
	def __init__(self, name, color, cost, n, type, deck, obs):
		self.name = name
		self.color = color
		self.cost = cost
		self.n = n
		self.type = type
		self.deck = deck
		self.obs = obs
